package com.example.lab08.videoview;

import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.MediaController;
import android.widget.VideoView;

public class MainActivity extends AppCompatActivity {


    VideoView video;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String videoPath="https://www.ahaber.com.tr/webtv/canli-yayin";
        Uri uri= Uri.parse(videoPath);

        video =(VideoView)findViewById(R.id.videoView);

        MediaController mediaController = new MediaController(this);
        mediaController.setAnchorView(video);

        video.setMediaController(mediaController);
        video.setVideoURI(uri);
        video.start();


    }
    @Override
    public void onPause() {
        super.onPause();
        if (video!= null) {
            video.pause();
        }
    }
    @Override
    public void onResume() {
        super.onResume();
        if (video != null) {
            video.start();
        }
    }


}
