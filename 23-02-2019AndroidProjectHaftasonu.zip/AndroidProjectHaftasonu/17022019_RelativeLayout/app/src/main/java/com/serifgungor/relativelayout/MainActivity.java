package com.serifgungor.relativelayout;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {


    EditText etKullanici, etSifre;
    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn = findViewById(R.id.btnGirisYap);
        etKullanici = findViewById(R.id.etKullaniciAdi);
        etSifre = findViewById(R.id.etSifre);
        //XML TARAFINDAKİ BİR NESNEYİ, DEĞİŞKENE BAĞLADIK

        //BUTONA TIKLAMA OLAYI
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //EDİTTEXT'İN ŞUANKİ DEĞERİNİ YAKALAMAK
                String kullanici = etKullanici.getText().toString();
                String sifre = etSifre.getText().toString();

                if ("admin".equals(kullanici) && "1234".equals(sifre)) {

                    Toast.makeText(getApplicationContext(), "Hoşgeldin", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Yanlış geldin", Toast.LENGTH_LONG).show();
                }


            }
        });


    }
}
