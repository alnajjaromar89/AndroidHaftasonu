package com.example.lab08.imagview;

import android.media.Image;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    Button btntr,btnit,btnjuvo,btnjuvn;
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btntr = findViewById(R.id.btntr);
        btnit = findViewById(R.id.btnit);
        btnjuvo = findViewById(R.id.btnjuvo);
        btnjuvn = findViewById(R.id.btnjuvn);

        imageView = findViewById(R.id.imageView);

        btntr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imageView.setImageResource(R.drawable.turkish_football);
            }
        });

        btnit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imageView.setImageResource(R.drawable.italy_logo);
            }
        });

        btnjuvo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imageView.setImageResource(R.drawable.juventus_old_logo);
            }
        });

        btnjuvn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imageView.setImageResource(R.drawable.juventus_logo);
            }
        });
    }
}
