package com.example.lab08.arrayadapterwithobject.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.lab08.arrayadapterwithobject.Model.Ogrenci;
import com.example.lab08.arrayadapterwithobject.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<Ogrenci> ogrenciler = new ArrayList<>();
    ListView listView;
    ArrayAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);

        ogrenciler.add(new Ogrenci("Omar","Alnajjar","MİS","alnajjaromar89@hotmail.com"));
        ogrenciler.add(new Ogrenci("Mostafa","Alnajjar","Tip","Mostafa@hotmail.com"));

        adapter = new ArrayAdapter<>(getApplicationContext(),android.R.layout.simple_list_item_1,ogrenciler);
        listView.setAdapter(adapter);




    }
}
