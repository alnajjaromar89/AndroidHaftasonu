package com.example.lab08.arrayadapterwithobject.Model;

public class Ogrenci{
    private String OgrenciAdi;
    private String OgrenciSoyAdi;
    private String OgrenciBolum;
    private String OgrenciEmail;

    @Override
    public String toString() {
        return "Ogrenci{" +
                "OgrenciAdi='" + OgrenciAdi + '\'' +
                ", OgrenciSoyAdi='" + OgrenciSoyAdi + '\'' +
                ", OgrenciBolum='" + OgrenciBolum + '\'' +
                ", OgrenciEmail='" + OgrenciEmail + '\'' +
                '}';
    }


    public Ogrenci() {

    }

    public Ogrenci(String ogrenciAdi, String ogrenciSoyAdi, String ogrenciBolum, String ogrenciEmail) {
        OgrenciAdi = ogrenciAdi;
        OgrenciSoyAdi = ogrenciSoyAdi;
        OgrenciBolum = ogrenciBolum;
        OgrenciEmail = ogrenciEmail;
    }



    public String getOgrenciAdi() {
        return OgrenciAdi;
    }

    public void setOgrenciAdi(String ogrenciAdi) {
        OgrenciAdi = ogrenciAdi;
    }

    public String getOgrenciSoyAdi() {
        return OgrenciSoyAdi;
    }

    public void setOgrenciSoyAdi(String ogrenciSoyAdi) {
        OgrenciSoyAdi = ogrenciSoyAdi;
    }

    public String getOgrenciBolum() {
        return OgrenciBolum;
    }

    public void setOgrenciBolum(String ogrenciBolum) {
        OgrenciBolum = ogrenciBolum;
    }

    public String getOgrenciEmail() {
        return OgrenciEmail;
    }

    public void setOgrenciEmail(String ogrenciEmail) {
        OgrenciEmail = ogrenciEmail;
    }
}
