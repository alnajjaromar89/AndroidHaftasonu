package com.example.lab08.android_custom_listview_kullanimi;

public class PhoneModel {
    private int indexId;
    private String nameSurname;
    private String phoneNumber;
    private String photo;

    public PhoneModel() {
    }

    public PhoneModel(int indexId, String nameSurname, String phoneNumber, String photo) {
        this.indexId = indexId;
        this.nameSurname = nameSurname;
        this.phoneNumber = phoneNumber;
        this.photo = photo;
    }

    public int getIndexId() {
        return indexId;
    }

    public void setIndexId(int indexId) {
        this.indexId = indexId;
    }

    public String getNameSurname() {
        return nameSurname;
    }

    public void setNameSurname(String nameSurname) {
        this.nameSurname = nameSurname;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }
}

